package com.perskiller.bms

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.view.Gravity
import android.widget.*
import android.app.Activity
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID

class MainActivity : Activity() {
    private val serviceId = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
    private val charId = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")
    private lateinit var adapter: BluetoothAdapter
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private val rx = ArrayList<Byte>()
    private var counter = 0
    private lateinit var status: TextView
    private lateinit var soc: TextView
    private lateinit var values: TextView
    private lateinit var log: TextView
    private lateinit var scanButton: Button
    private val devices = linkedMapOf<String, BluetoothDevice>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        adapter = manager.adapter
        scanner = adapter.bluetoothLeScanner
        buildUi()
        requestBtPermissions()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF0B1117.toInt())
        }
        fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 10, 0, 10)
            }
        root.addView(label("PERSKILLER", 23f, 0xFFFFFFFF.toInt(), true))
        root.addView(label("BMS MONITOR · JK02 · ТОЛЬКО ЧТЕНИЕ", 12f, 0xFF5DE0A0.toInt()))
        status = label("Не подключено", 14f, 0xFFB4C3CD.toInt())
        root.addView(status)
        scanButton = Button(this).apply { text = "НАЙТИ МОЮ BMS"; setOnClickListener { startScan() } }
        root.addView(scanButton)
        soc = label("--%", 56f, 0xFF5DE0A0.toInt(), true).apply { gravity = Gravity.CENTER }
        root.addView(soc)
        root.addView(label("ЗАРЯД АККУМУЛЯТОРА", 12f, 0xFFB4C3CD.toInt()).apply { gravity = Gravity.CENTER })
        values = label("Напряжение: -- V\nТок: -- A\nТемпература MOS: -- °C\nТемпература 1: -- °C\nТемпература 2: -- °C\nЯчейки: ожидание данных", 18f, 0xFFFFFFFF.toInt())
        root.addView(values)
        log = label("Готов к поиску BLE-устройств JK.", 12f, 0xFF9EB0BD.toInt())
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestBtPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 77)
    }

    private fun startScan() {
        if (!hasPermissions()) { requestBtPermissions(); return }
        if (!adapter.isEnabled) { status.text = "Включи Bluetooth на телефоне"; return }
        devices.clear()
        status.text = "Сканирование Bluetooth LE…"
        scanButton.isEnabled = false
        val filters = listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(serviceId)).build())
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        try {
            scanner?.startScan(filters, settings, scanCallback)
            window.decorView.postDelayed({ stopScan() }, 12000)
        } catch (e: SecurityException) {
            status.text = "Нет разрешения Bluetooth: ${e.message}"
            scanButton.isEnabled = true
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val key = try { d.address } catch (_: SecurityException) { "unknown" }
            devices[key] = d
            runOnUiThread {
                status.text = "Найдено BLE-устройств: ${devices.size}"
                log.text = devices.entries.joinToString("\n") { (addr, dev) ->
                    val name = try { dev.name ?: "Без имени" } catch (_: SecurityException) { "BMS" }
                    "$name · $addr"
                }
                if (devices.size == 1) connect(d)
            }
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { status.text = "Ошибка сканирования: $errorCode"; scanButton.isEnabled = true }
        }
    }

    private fun stopScan() {
        try { if (hasPermissions()) scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        scanButton.isEnabled = true
        if (gatt == null) status.text = "Поиск завершён. Найдено: ${devices.size}"
    }

    private fun connect(device: BluetoothDevice) {
        stopScan()
        status.text = "Подключение к ${try { device.name ?: device.address } catch (_: Exception) { "BMS" }}…"
        try {
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) { status.text = "Не удалось подключиться: ${e.message}" }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { status.text = "Bluetooth подключён · поиск службы JK…" }
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread { status.text = "Отключено"; scanButton.isEnabled = true }
                g.close(); gatt = null
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(serviceId)
            if (service == null) { runOnUiThread { status.text = "Служба JK FFE0 не найдена" }; return }
            val chars = service.characteristics.filter { it.uuid == charId }
            writeChar = chars.firstOrNull { it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0 }
            notifyChar = chars.firstOrNull { it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 }
            if (writeChar == null || notifyChar == null) {
                runOnUiThread { status.text = "FFE1 найдена, но характеристики несовместимы" }; return
            }
            g.setCharacteristicNotification(notifyChar, true)
            val cccd = notifyChar?.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
            if (cccd != null) {
                cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                g.writeDescriptor(cccd)
            } else sendReadRequests()
            runOnUiThread { status.text = "JK BLE найден · включаю уведомления…" }
        }
        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, statusCode: Int) {
            sendReadRequests()
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            acceptBytes(value)
        }
        @Deprecated("Deprecated in Android 13")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            characteristic.value?.let { acceptBytes(it) }
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            // Read-only requests only; no setting or control writes are implemented.
        }
    }

    private fun sendReadRequests() {
        writeCommand(0x96)
        window.decorView.postDelayed({ writeCommand(0x97) }, 250)
        runOnUiThread { status.text = "Подключено · запрос телеметрии отправлен" }
    }

    private fun writeCommand(command: Int) {
        val c = writeChar ?: return
        val frame = ByteArray(20)
        frame[0] = 0xAA.toByte(); frame[1] = 0x55; frame[2] = 0x90.toByte(); frame[3] = 0xEB.toByte()
        frame[4] = command.toByte(); frame[16] = (counter++ and 0xFF).toByte()
        var sum = 0; for (i in 0 until 19) sum = (sum + (frame[i].toInt() and 0xFF)) and 0xFF
        frame[19] = sum.toByte()
        c.value = frame
        c.writeType = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        try { gatt?.writeCharacteristic(c) } catch (_: Exception) {}
    }

    @Synchronized private fun acceptBytes(bytes: ByteArray) {
        bytes.forEach { rx.add(it) }
        while (rx.size >= 300) {
            val start = (0 until (rx.size - 3)).firstOrNull {
                (rx[it].toInt() and 255) == 0x55 && (rx[it+1].toInt() and 255) == 0xAA &&
                (rx[it+2].toInt() and 255) == 0xEB && (rx[it+3].toInt() and 255) == 0x90
            }
            if (start == null) { while (rx.size > 3) rx.removeAt(0); return }
            repeat(start) { rx.removeAt(0) }
            if (rx.size < 300) return
            val frame = ByteArray(300) { rx[it] }
            var sum = 0; for (i in 0 until 299) sum = (sum + (frame[i].toInt() and 255)) and 255
            repeat(300) { rx.removeAt(0) }
            if (sum == (frame[299].toInt() and 255) && (frame[4].toInt() and 255) == 2) parseStatus(frame)
        }
    }

    private fun parseStatus(f: ByteArray) {
        fun u16(o: Int) = ((f[o].toInt() and 255) or ((f[o+1].toInt() and 255) shl 8))
        fun i16(o: Int) = u16(o).let { if (it >= 32768) it - 65536 else it }
        fun u32(o: Int) = (f[o].toLong() and 255) or ((f[o+1].toLong() and 255) shl 8) or
            ((f[o+2].toLong() and 255) shl 16) or ((f[o+3].toLong() and 255) shl 24)
        val volts = (0 until 32).map { u16(6 + it*2) / 1000.0 }.filter { it in 0.5..5.0 }
        val voltage = u32(150) / 1000.0
        val current = ByteBuffer.wrap(f, 158, 4).order(ByteOrder.LITTLE_ENDIAN).int / 1000.0
        val mosTemp = i16(144) / 10.0
        val t1 = i16(162) / 10.0
        val t2 = i16(164) / 10.0
        val charge = f[173].toInt() and 255
        runOnUiThread {
            soc.text = "$charge%"
            values.text = "Напряжение: %.2f V\nТок: %.2f A\nТемпература MOS: %.1f °C\nТемпература 1: %.1f °C\nТемпература 2: %.1f °C\nЯчеек обнаружено: %d\n%s".format(
                voltage, current, mosTemp, t1, t2, volts.size,
                volts.mapIndexed { i, v -> "${i+1}: %.3f V".format(v) }.joinToString("   ")
            )
            status.text = "Подключено · данные BMS обновлены"
        }
    }

    private fun hasPermissions(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return p.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    override fun onDestroy() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
